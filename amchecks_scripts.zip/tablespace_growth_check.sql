--
-- Tony Webb 19th May 2016
--
-- This script expects 1 parameter to be passed - database_name
-- 'ALL' can be passed as database name and wild-cards can be used for partial database names
--
-- It will list current tablespace size of the database(s) using daily info captured for the last month (assuming this information is being captured).
-- Two parameters MUST be supplied. First is database name (fuzzy matched so '%' is OK, as 'is 'ALL'); Second is 'ALL' for verbose listing - anything else is ignored.
--
-- The '0.00001' nonsence is to avoid any 'divide by zero' errors
--

SET TAB OFF
SET LINES 180 PAGES 1000
SET VERIFY OFF
SET TERMOUT OFF
SET HEADING OFF
SET FEEDBACK OFF

COLUMN v_db new_value DATABASE_NAME noprint
COLUMN v_verbose new_value VERBOSE noprint

WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

SELECT DECODE(UPPER('&1'),'ALL','%',UPPER('&1')) AS v_db, DECODE(UPPER('&2'),'ALL','Y',UPPER('&2')) AS v_verbose
FROM dual;

SET TERMOUT ON
SET SERVEROUTPUT ON

PROMPT
PROMPT Recent Tablespace Growth
PROMPT =========================

DECLARE
    v_rec_count      PLS_INTEGER:=0;
BEGIN

FOR c1 IN (
WITH
    now_size   AS (SELECT * FROM (SELECT  database_name,
                           server,
                           tablespace_name,
                           NVL(meg_used,0) AS now_meg_used,
                           space_time      AS now_space_time,
                           LAST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS now_last_space_time
                  FROM     amo.am_tablespace_month_space
                  WHERE    database_name LIKE '&DATABASE_NAME'
                  AND      space_time > sysdate - 1)
                  where now_space_time = now_last_space_time
                  ORDER BY tablespace_name, now_space_time, now_meg_used
                  ),
    yd_size AS (SELECT * FROM (SELECT    database_name, server,
                          tablespace_name,
                          NVL(meg_used,0) AS yd_meg_used,
                          space_time      AS yd_space_time,
                          FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS yd_first_space_time
                   FROM   amo.am_tablespace_month_space
                   WHERE space_time between sysdate - 2 and sysdate -1
                   AND   database_name LIKE '&DATABASE_NAME')
                   where yd_space_time = yd_first_space_time
                   ORDER BY tablespace_name, yd_space_time, yd_meg_used
                   ),
    lw_size AS (SELECT * FROM (SELECT    database_name, server,
                          tablespace_name,
                          NVL(meg_used,0) AS lw_meg_used,
                          space_time      AS lw_space_time,
                          FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS lw_first_space_time
                   FROM   amo.am_tablespace_month_space
                   WHERE space_time between sysdate - 7 and sysdate -2
                   AND   database_name LIKE '&DATABASE_NAME')
                   where lw_space_time = lw_first_space_time
                   ORDER BY tablespace_name, lw_space_time, lw_meg_used
                   ),
    lm_size AS (SELECT * FROM (SELECT    database_name, server,
                          tablespace_name,
                          NVL(meg_used,0) AS lm_meg_used,
                          space_time      AS lm_space_time,
                          FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS lm_first_space_time
                   FROM   amo.am_tablespace_month_space
                   WHERE space_time between sysdate - 31 and sysdate -7
                   AND   database_name LIKE '&DATABASE_NAME')
                   where lm_space_time = lm_first_space_time
                   ORDER BY tablespace_name, lm_space_time, lm_meg_used
                   )
SELECT SUBSTR(n.database_name || ' on ' || n.server,1,40) AS server,
        SUBSTR(n.tablespace_name,1,20) AS tablespace_name,
        n.now_space_time AS date_now,
        LPAD(TO_CHAR(n.now_meg_used,'999,999,999'),12) AS now_meg_used,
        LPAD(NVL(TO_CHAR(yd_meg_used,'999,999,999'),'       ---  '),12) AS yd_meg_used,
        LPAD(NVL(TO_CHAR(lw_meg_used,'999,999,999'),'       ---  '),12) AS lw_meg_used,
        LPAD(NVL(TO_CHAR(lm_meg_used,'999,999,999'),'       ---  '),12) AS lm_meg_used,
        DECODE(yd_meg_used,NULL,NULL,TO_CHAR(((now_meg_used+0.00001 - yd_meg_used+0.00001)/(yd_meg_used+0.00001) * 100 ),'9,990.99') || '%') as day_growth,
        DECODE(lw_meg_used,NULL,NULL,TO_CHAR(((now_meg_used+0.00001 - lw_meg_used+0.00001)/(lw_meg_used+0.00001) * 100 ),'9,990.99') || '%') as week_growth,
        DECODE(lm_meg_used,NULL,NULL,TO_CHAR(((now_meg_used+0.00001 - lm_meg_used+0.00001)/(lm_meg_used+0.00001) * 100 ),'9,990.99') || '%') as month_growth
 FROM  now_size n,
       yd_size y,
       lw_size w,
       lm_size m
       WHERE n.database_name = y.database_name (+)
       AND   n.server = y.server (+)
       AND   n.tablespace_name = y.tablespace_name (+)
       AND   n.database_name = w.database_name (+)
       AND   n.server = w.server (+)
       AND   n.tablespace_name = w.tablespace_name (+)
       AND   n.database_name = m.database_name (+)
       AND   n.server = m.server (+)
       AND   n.tablespace_name = m.tablespace_name (+)
       AND   (
                  (now_meg_used > (yd_meg_used * 1.05)) 
              OR    ((now_meg_used > 10000) and (now_meg_used > yd_meg_used * 1.02)) 
              OR    (lw_meg_used IS NOT NULL and (now_meg_used > lw_meg_used * 1.02))  
              OR    (lw_meg_used IS NOT NULL and ((now_meg_used > 10000) and (now_meg_used > lw_meg_used * 1.01)))
              OR    (lm_meg_used IS NOT NULL and (now_meg_used > lm_meg_used * 1.01))  
              OR    (lm_meg_used IS NOT NULL and ((now_meg_used > 10000) and (now_meg_used > lm_meg_used * 1.005)))
              OR    ('&VERBOSE' = 'Y')
             )
    ORDER BY n.database_name, n.server, n.tablespace_name
)
LOOP
   IF (v_rec_count < 1)
   THEN
       DBMS_OUTPUT.PUT_LINE('Database                                 Tablespace Date Now       Space(MB)     Y' || CHR(39) || 'Day(MB)   Last Wk(MB)   Last Mth(MB)  Day Growth    Wk Growth   Mth Growth');
       DBMS_OUTPUT.PUT_LINE('---------                               ----------- ---------      ---------     ---------   -----------   ------------  -----------   ----------  -----------');
   END IF;
 
   DBMS_OUTPUT.PUT_LINE(RPAD(c1.server,30) || ' ' ||
                              LPAD(c1.tablespace_name,20) || ' ' ||
                              RPAD(TO_CHAR(c1.date_now,'DD-MON-YY'),10) || ' ' ||
                              LPAD(c1.now_meg_used,13) || ' ' ||
                              LPAD(c1.yd_meg_used,13) || ' ' ||
                              LPAD(c1.lw_meg_used,13) || ' ' ||
                              LPAD(c1.lm_meg_used,13) || ' ' ||
                              LPAD(NVL(c1.day_growth,'---  '),12) || ' ' ||
                              LPAD(NVL(c1.week_growth,'---  '),12) || ' ' ||
                              LPAD(NVL(c1.month_growth,'---  '),12));
    v_rec_count:= v_rec_count + 1;
END LOOP;
IF (v_rec_count < 1)
THEN
   DBMS_OUTPUT.PUT_LINE('No growing tablespaces found.');
END IF;
END;
/
