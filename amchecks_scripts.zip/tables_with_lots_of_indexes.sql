set lines 120
set pages 1000
col table_name format a50

SELECT i.owner || '.' ||  i.table_name AS table_name, 
       i.index_count, 
       c.column_count
FROM (SELECT table_owner AS owner,
             table_name, 
             count(*) AS index_count  
      FROM dba_indexes     
      GROUP BY table_owner, table_name 
      HAVING COUNT(*) > 9) i,
      (SELECT owner,
              table_name, 
              count(*) AS column_count 
       FROM dba_tab_columns 
       GROUP BY owner, table_name) c
WHERE i.table_name = c.table_name
AND   i.owner = c.owner
AND   i.owner NOT LIKE 'APEX%'
AND   i.owner NOT IN (SELECT user_name FROM sys.default_pwd$)
ORDER BY 2 DESC, 1
/

