create user amr identified by change_this;
grant create session to amr;
grant select on amo.am_database to amr;

