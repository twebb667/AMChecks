--
-- Lovingly crafted by Tony Webb 14th May 2015
--
-- An error is reported if the gap is an hour or more or more than 2 logs
-- Note that there is no allowance of deliberate delays at present (delay_mins from v$managed_standby)
--

WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET HEADING OFF
SET FEEDBACK OFF
SET LINES 200
SET SERVEROUTPUT ON
SET TAB off

DECLARE
  v_archived_sequence v$archived_log.sequence#%TYPE;
  v_archived_time     v$archived_log.completion_time%TYPE;
  v_count             PLS_INTEGER:=0;
  v_database          v$database.name%TYPE:=SYS_CONTEXT('USERENV','DB_NAME');
  v_destination       v$archive_dest.destination%TYPE;
  v_gap_in_minutes    NUMBER(38);
  v_lag_status        VARCHAR2(20);
  v_standby_sequence  v$archived_log.sequence#%TYPE;
  v_standby_status    VARCHAR2(200);
  v_standby_time      VARCHAR2(20);

BEGIN

  v_standby_status:='** No Standby Found for ' || v_database || ' **';

  SELECT COUNT(*) 
  INTO   v_count 
  FROM   v$archive_dest_status
  WHERE  type <> 'LOCAL';

  IF (v_count > 0)
  THEN
      SELECT s.destination, 
             l1.sequence# AS archived_sequence,
             l1.completion_time AS archived_time, 
             s.sequence# AS standby_sequence,
             NVL(TO_CHAR(l2.completion_time, 'DD-MM-YY hh24:mi:ss'),'CURRENT') AS standby_time,
             ROUND(((NVL(l2.completion_time, l1.completion_time)) - (l1.completion_time)) * (24*60)) AS gap_in_minutes
      INTO   v_destination,
             v_archived_sequence,
             v_archived_time,
             v_standby_sequence,
             v_standby_time,
             v_gap_in_minutes
      FROM   v$archived_log l1,
             v$archived_log l2,
             (select dest_id, MAX(sequence#)    AS sequence# FROM v$archived_log GROUP BY dest_id) m,
             (select dest_id, MAX(log_sequence) AS sequence#, destination FROM v$archive_dest WHERE target='STANDBY' AND status='VALID' GROUP BY dest_id, destination) s
      WHERE  m.sequence# = l1.sequence#
      AND    m.dest_id = l1.dest_id
      AND    m.dest_id = s.dest_id(+)
      AND    s.sequence# = l2.sequence#(+)
      AND    s.destination IS NOT NULL;

    IF (v_standby_sequence IS NULL)
    THEN
      v_standby_status:='** ERROR on ' || v_database || ':- Standby log information is not available. Standby may be disabled? **';
    ELSE     
        IF (v_gap_in_minutes > 59)
        THEN
          v_standby_status:='** ERROR on ' || v_database || ':- Standby is lagging by ' || TO_CHAR(v_gap_in_minutes) || ' minutes. Last applied log is ' || TO_CHAR(v_standby_sequence) || ' but it should be ' || TO_CHAR(v_archived_sequence) || ' **';
        ELSE 
            IF (v_archived_sequence > v_standby_sequence +2)
            THEN
                v_standby_status:='** ERROR on ' || v_database || ':- Standby is lagging by ' || TO_CHAR(v_archived_sequence - v_standby_sequence) || ' logs. Last applied log is ' || TO_CHAR(v_standby_sequence) || ' but it should be ' || TO_CHAR(v_archived_sequence) || ' **';
            ELSE
                v_standby_status:='** Standby is up-to-date for ' || v_database || ' **';
            END IF;
        END IF;
    END IF;
  END IF;

  DBMS_OUTPUT.PUT_LINE(v_standby_status);

EXCEPTION
WHEN NO_DATA_FOUND 
THEN
      DBMS_OUTPUT.PUT_LINE('** ERROR on ' || v_database || ':- Standby log information is not available. Standby may be disabled? **');
END;
/
