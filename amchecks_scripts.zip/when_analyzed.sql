
--------------------------------------
-- Written by Tony Webb 27 Jan 2016   
-- Could do with being optimized tbh 
--------------------------------------
WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET PAGES 1000
SET HEADING on
SET FEEDBACK off
SET LINES 200
SET SERVEROUTPUT on
SET TAB OFF
COL owner  format a20 HEADING 'Table Owner'
COL table_count  format a12 HEADING 'Table Count'
COL week_stats HEADING '<1 Week'
COL month_stats HEADING '<1 Month'
COL old_stats HEADING '<6 Months'
COL vold_stats HEADING ' >6 Months'
COL no_stats HEADING 'NO STATS'

prompt
prompt Table stats (age by schema)
prompt ===========================

WITH all_tables AS
    (SELECT owner,
            NVL(COUNT(*),0) AS tabcount
     FROM   dba_tables
     WHERE  owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner),
week_stats AS
    (SELECT owner,
            COUNT(*) AS tabcount
     FROM   dba_tables
     WHERE  last_analyzed > TRUNC(sysdate -7)
     AND    owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner),
month_stats AS
    (SELECT owner,
            COUNT(*) AS tabcount
     FROM   dba_tables
     WHERE  last_analyzed >= TRUNC(sysdate -31) 
     AND    last_analyzed <= TRUNC(sysdate -7)
     AND    owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner),
old_stats AS
    (SELECT owner,
            COUNT(*) AS tabcount
     FROM   dba_tables
     WHERE  last_analyzed >= TRUNC(sysdate -183)
     AND    last_analyzed <= TRUNC(sysdate -31)
     AND    owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner),
vold_stats AS
    (SELECT owner,
            COUNT(*) AS tabcount
     FROM   dba_tables
     WHERE  last_analyzed < TRUNC(sysdate -183)
     AND    owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner),
no_stats AS
    (SELECT owner,
            COUNT(*) AS tabcount
     FROM   dba_tables
     WHERE  last_analyzed IS NULL
     AND    owner not like '%SYS%'
     AND    owner NOT IN ('DBSNMP', 'OUTLN', 'XDB' )
     AND    temporary <> 'Y'
     GROUP BY owner)
SELECT t.owner, 
       LPAD('(' || LTRIM(TO_CHAR(t.tabcount,'999,990')) || ')',12) AS table_count,
       NVL(w.tabcount,0) AS week_stats,
       NVL(m.tabcount,0) AS month_stats,
       NVL(o.tabcount,0) AS old_stats, 
       NVL(v.tabcount,0) AS vold_stats, 
       NVL(n.tabcount,0) AS no_stats 
FROM   all_tables t,
       week_stats w,
       month_stats m,
       old_stats o,
       vold_stats v,
       no_stats n
WHERE t.owner = w.owner (+)
AND   t.owner = m.owner (+)
AND   t.owner = o.owner (+)
AND   t.owner = v.owner (+)
AND   t.owner = n.owner (+)
ORDER BY 1
/

prompt
