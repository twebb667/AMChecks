
--
-- Tony Webb 20th Jan 2016
--
-- This script expects 1 parameter to be passed - database_name 
-- 'ALL' can be passed as database name and wild-cards can be used for partial database names
--
-- It will list current size of the database(s) by tablespace from the latest run of 'tablespace_space_check.ksh'
-- along with growth results for the last month, 6 months and year.
--

--
-- Tony Webb 18th May 2016 - changes to outer joins.
-- Tony Webb 19th May 2016 - More rewrites
-- Tony Webb 14th Dec 2016 - Second parameter (server) added 
--

SET TAB OFF
SET LINES 180 PAGES 1000
SET VERIFY OFF
SET TERMOUT OFF
SET HEADING OFF
SET FEEDBACK OFF

PROMPT
PROMPT Database Growth By Tablespace
PROMPT ==============================

COLUMN v_db new_value DATABASE_NAME noprint

WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET VERIFY OFF
SET TERMOUT OFF
COLUMN 1 new_value 1
COLUMN 2 new_value 2
SELECT ''  AS "1" , '' AS "2" FROM dual WHERE ROWNUM = 0;
DEFINE PARAM1 = '&1'
DEFINE PARAM2 = '&2'
SET TERMOUT ON
SET SERVEROUTPUT ON

DECLARE
    v_dbname         VARCHAR2(15); 
    v_rec_count      PLS_INTEGER:=0;
    v_rec_count2     PLS_INTEGER:=0;
    v_parameter      VARCHAR2(2000);
    v_last_server    VARCHAR2(60);
    v_last_date      VARCHAR2(60);
    v_server         VARCHAR2(60); 
    v_this_server    VARCHAR2(60);
    v_this_date      VARCHAR2(60);
    v_title          VARCHAR2(200):='Database                       Tablespace           Date Now     Space (MB)    Last Mth(MB)                         Last Yr(MB)';
    v_underline      VARCHAR2(200):='------------------------------ -------------------  ------------ ------------- -----------------------------------  -----------------------------------';
BEGIN

v_dbname := NVL(UPPER('&PARAM1'),'%');
v_server := NVL(UPPER('&PARAM2'),'%');

-- DBMS_OUTPUT.PUT_LINE(v_title);
-- DBMS_OUTPUT.PUT_LINE(v_underline);
-- DBMS_OUTPUT.PUT_LINE(v_dbname);
-- DBMS_OUTPUT.PUT_LINE(v_server);

FOR c1 IN (
WITH now_size AS (select * from (SELECT   * from (select database_name,
                           server,
                           tablespace_name,
                           NVL(meg_used,0) AS now_meg_used,
                           space_time      AS now_space_time,
                           FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS now_first_space_time
                  FROM     amo.am_tablespace_space
                  WHERE space_time > sysdate - 7
                  AND   database_name LIKE v_dbname
                  AND   UPPER(server) LIKE v_server
                  ORDER BY database_name, tablespace_name, now_meg_used DESC, now_space_time DESC)
                  where now_space_time = now_first_space_time
                  ORDER BY database_name, tablespace_name, now_space_time DESC, now_meg_used)),
    month_size AS (select * from (SELECT * from (select database_name,
                          server,
                           tablespace_name,
                          NVL(meg_used,0) AS month_meg_used,
                          space_time      AS month_space_time,
                          FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS month_first_space_time
                   FROM   amo.am_tablespace_space
                   WHERE space_time < sysdate - 7
                   AND   space_time > sysdate -31
                   AND   database_name LIKE v_dbname
                   AND   UPPER(server) LIKE v_server
                   ORDER BY database_name, tablespace_name, month_meg_used DESC, month_space_time DESC)
                   where month_space_time = month_first_space_time
                   ORDER BY database_name, tablespace_name, month_space_time DESC, month_meg_used)),
    year_size  AS (select * from (SELECT * from (select database_name,
                          server,
                           tablespace_name,
                          NVL(meg_used,0) AS year_meg_used,
                          space_time      AS year_space_time,
                          FIRST_VALUE(space_time) OVER (PARTITION BY database_name, tablespace_name ) AS year_first_space_time
                   FROM   amo.am_tablespace_space
                   WHERE space_time < sysdate - 31
                   AND   space_time > sysdate -365
                   AND   database_name LIKE v_dbname
                   AND   UPPER(server) LIKE v_server
                   ORDER BY database_name, tablespace_name, year_meg_used DESC, year_space_time DESC)
                   where year_space_time = year_first_space_time
                   ORDER BY database_name, tablespace_name, year_space_time DESC, year_meg_used
                   ))
SELECT SUBSTR(n.database_name || ' on ' || n.server,1,40) AS server,
        SUBSTR(n.tablespace_name,1,20) AS tablespace_name,
        n.now_space_time AS date_now,
        LPAD(n.now_meg_used,12) AS now_meg_used,
        CASE
             WHEN (month_meg_used = now_meg_used) OR (month_meg_used = 0) OR (month_meg_used IS NULL) THEN NULL
             ELSE TO_CHAR((now_meg_used - month_meg_used),'999,990') || '(MB) '
                  || (TO_CHAR(((now_meg_used - month_meg_used)/(month_meg_used) * 100 ),'9990.99') || '%')
        END AS month_growth,
        month_meg_used,
        CASE
             WHEN (year_meg_used = now_meg_used) OR (year_meg_used = 0) OR (year_meg_used IS NULL) THEN NULL
             ELSE TO_CHAR((now_meg_used - year_meg_used),'999,990') || '(MB) '
                  || (TO_CHAR(((now_meg_used - year_meg_used)/(year_meg_used) * 100 ),'9990.99') || '%')
        END AS year_growth,
        year_meg_used
   FROM  now_size n,
         month_size m,
         year_size y
       WHERE n.database_name = m.database_name (+)
       AND   n.server = m.server (+)
       AND   n.tablespace_name = m.tablespace_name (+)
       AND   n.database_name = y.database_name (+)
       AND   n.server = y.server (+)
       AND   n.tablespace_name = y.tablespace_name (+)
    ORDER BY n.database_name, n.server, n.tablespace_name
)
LOOP
   v_this_server := c1.server;
   v_this_date := TO_CHAR(c1.date_now,'DD-MON-YYYY');
   IF (v_this_server = v_last_server)
   THEN
      v_this_server:=   '...............................';
      IF (v_this_date = v_last_date)
      THEN
          v_this_date:= '...............................';
       END IF;
   ELSE
       v_this_server := RPAD(v_this_server,31,'.');
       DBMS_OUTPUT.PUT_LINE(CHR(10));
       DBMS_OUTPUT.PUT_LINE(v_title);
       DBMS_OUTPUT.PUT_LINE(v_underline);
   END IF;

   DBMS_OUTPUT.PUT_LINE(v_this_server || 
                              RPAD(c1.tablespace_name,20) || ' ' ||
                              RPAD(v_this_date,12) || ' ' || 
                              LPAD(TO_CHAR(c1.now_meg_used,'99,999,990'),11) || ' ' ||
                              RPAD(LPAD(TO_CHAR(c1.month_meg_used, '99,999,990'),11) || ' ' || c1.month_growth,35) || ' ' ||
                              RPAD(LPAD(TO_CHAR(c1.year_meg_used, '99,999,990'),11)  || ' ' || c1.year_growth,35));
    v_last_server := c1.server;
    v_last_date := TO_CHAR(c1.date_now,'DD-MON-YY');
    v_rec_count:= v_rec_count + 1;
END LOOP;

END;
/

-- PROMPT
-- PROMPT Note that if historical space details aren't found the details used for the space calculations
-- PROMPT will be based on the nearest date since the specified time.
-- PROMPT
