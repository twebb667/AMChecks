set pages 1000
set lines 200
col seg format A82
--
-- Original sql taken from --http://sureshgandhi.wordpress.com/tag/db-growth-reports/

--
-- Be careful as selecting from most DBA_HIST views requires a valid diagnostic license to be in place from Oracle Corp 
-- At the time of writing DBA_HIST_SEG_STAT is excluded from this requirement (see http://docs.oracle.com/cd/E11882_01/license.112/e47877/options.htm#DBLIC160)
-- and look for the bit that says:
--
-- "All data dictionary views beginning with the prefix DBA_HIST_ are part of this pack, along with their underlying tables.
-- The only exception are the views: DBA_HIST_SNAPSHOT, DBA_HIST_DATABASE_INSTANCE, DBA_HIST_SNAP_ERROR, DBA_HIST_SEG_STAT, DBA_HIST_SEG_STAT_OBJ, 
-- and DBA_HIST_UNDOSTAT. They can be used without the Oracle Diagnostics Pack license."
--
-- I guess this could change at any time though so please check before using this script. You have been warned!
--

PROMPT Segment Growth (Only showing non-SYS objects)

SELECT seg, "Tablespace Name", growth "Growth (MB)", totsize "Total Size (MB)", round((growth/(totsize -growth)) * 100,2) "Growth %"
FROM (
SELECT REPLACE(o.OWNER || '.' || o.OBJECT_NAME || ' - ' || o.SUBOBJECT_NAME || ' (' || o.OBJECT_TYPE || ') ', '  ', ' ') AS seg ,
       t.NAME "Tablespace Name", s.growth/(1024*1024) AS growth,
       (SELECT sum(bytes)/(1024*1024) FROM dba_segments WHERE segment_name=o.object_name) AS totsize
FROM  DBA_OBJECTS o,
      (SELECT TS#,OBJ#, SUM(SPACE_USED_DELTA) growth FROM DBA_HIST_SEG_STAT GROUP BY TS#,OBJ# HAVING SUM(SPACE_USED_DELTA) > 0 ORDER BY 2 DESC ) s,
      v$tablespace t
WHERE s.OBJ# = o.OBJECT_ID
AND   o.owner <> 'SYS'
AND   s.TS#=t.TS#
AND   rownum < 51)
ORDER BY 4 DESC, 1 DESC
/

