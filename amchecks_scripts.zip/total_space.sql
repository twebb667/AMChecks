-- 
-- AMW 26th May 2015
-- Intended to run on all databases and results uploaded to a spreadsheet (or similar)
--
set lines 200
set pages 0
set feedback off

SELECT SYS_CONTEXT('USERENV','DB_NAME') || TO_CHAR(sum(gig),'999,999.90') || ' Gig' AS gig_total 
FROM
(SELECT SUM(bytes)/1024/1024/1024 AS gig FROM dba_data_files
UNION ALL
SELECT SUM(bytes)/1024/1024/1024 FROM dba_temp_files)
/

exit;

