WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET FEEDBACK off
REM largely pinched from the web. 
REM changes by amw to include OS space and a few other twiddles (linux only)

PROMPT
PROMPT Tablespace Space Usage
PROMPT ======================
PROMPT
PROMPT IMPORTANT: Note that Max Size(GB) assumes that a single datafile is able to use ALL available space in a mount point.
PROMPT In practice this will not happen as other datafiles are likely to also use this space.
PROMPT In addition this script relies on the 'dfspace' external table to be UP-TO-DATE.
PROMPT

COL pic1 FORMAT a22 HEADING ''
COL pic2 FORMAT a22 HEADING ''
COL tablespace_name FORMAT a30 HEADING 'Tablespace' JUSTIFY LEFT
COL max_size FORMAT 999,990.99 HEADING 'Max Size(GB)' JUSTIFY CENTER
COL actual_size FORMAT 999,990.99 HEADING 'Actual Size(GB)' JUSTIFY CENTER
COL used FORMAT 9,990.99 HEADING 'Used(GB)' JUSTIFY CENTER
COL free FORMAT 9,990.99 HEADING 'Free(GB)' JUSTIFY CENTER
COL pct_used FORMAT a9 HEADING '% Used' JUSTIFY CENTER
COL pct_max FORMAT a9 HEADING '% Max' JUSTIFY CENTER

COMPUTE SUM LABEL Total OF actual_size ON REPORT
COMPUTE SUM LABEL Total OF used ON REPORT
COMPUTE SUM LABEL Total OF free ON REPORT
BREAK ON tablespace ON REPORT

SET LINES 200 PAGES 1000 TAB OFF

SELECT tablespace_name,
       tablespace_max_size/(1024 * 1024 * 1024)            AS max_size,
       tablespace_size/(1024 * 1024 * 1024)                AS actual_size,
       used_bytes/(1024 * 1024 * 1024)                     AS used,
       (tablespace_size - used_bytes)/(1024 * 1024 * 1024) AS free,
       TO_CHAR(DECODE(tablespace_size,NULL,0,NVL(ROUND((tablespace_size - (tablespace_size - used_bytes))/(tablespace_size)*100,2),100)),'990.99') || ' %' AS pct_used,
       CASE WHEN (tablespace_size IS NULL)
            THEN 
                 '['||RPAD(LPAD('OFFLINE',13,'-'),20,'-')||']'
            ELSE '['|| DECODE((tablespace_size - used_bytes),
                 null,'XXXXXXXXXXXXXXXXXXXX',
                 NVL(RPAD(LPAD('X',round((100-ROUND( (tablespace_size - used_bytes)/(tablespace_size) * 100, 2))/5),'X'),20,'-'),'--------------------'))||']'
            END as pic1,  
       TO_CHAR(DECODE(tablespace_max_size,NULL,0,NVL(ROUND((tablespace_max_size - (tablespace_max_size - used_bytes))/(tablespace_max_size)*100,2),100)),'990.99') || ' %' AS pct_max,
       CASE WHEN (tablespace_max_size IS NULL)
            THEN 
                '['||RPAD(LPAD('OFFLINE',13,'-'),20,'-')||']'
            ELSE '['|| DECODE((tablespace_max_size - used_bytes),null,'XXXXXXXXXXXXXXXXXXXX',NVL(RPAD(LPAD('X',
                       round((100-ROUND( (tablespace_max_size - used_bytes)/(tablespace_max_size) * 100, 2))/5),'X'),20,'-'),'--------------------'))||']'
            END AS pic2
FROM
     (SELECT tablespace_name,
             tablespace_size,
             tablespace_max_size,
             used_bytes
      FROM   (SELECT t.tablespace_name,
                     t.tablespace_size,
                     t.tablespace_max_size,
                     nvl(u.used_bytes,0) AS used_bytes
              FROM   (SELECT tablespace_name,
                             SUM(totalb) AS tablespace_size,
                             SUM(maxb)   AS tablespace_max_size
                      FROM   (SELECT f.tablespace_name AS tablespace_name,
                                     SUM(LEAST(DECODE(NVL(f.maxbytes,0),0,bytes,f.maxbytes), (d.free_space))) AS maxb,
                                     SUM(f.bytes) AS totalb
                              FROM   dba_data_files f,
                                     amo.dfspace d
                              WHERE f.autoextensible = 'YES'
                              and  d.full_file_name = f.file_name
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT f.tablespace_name,
                                     SUM(LEAST(DECODE(NVL(f.maxbytes,0),0,bytes,f.maxbytes), (d.free_space))),
                                     SUM(f.bytes) AS totalb
                              FROM   dba_temp_files f,
                                     amo.dfspace d
                              WHERE f.autoextensible = 'YES'
                              and   d.full_file_name = f.file_name
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_data_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_temp_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_temp_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name)
                     GROUP BY tablespace_name) t,
                     (SELECT  f.tablespace_name, 
                              SUM(d.total_bytes - f.free_bytes) AS used_bytes
                      FROM    (SELECT SUM(bytes) AS free_bytes,  
                                      tablespace_name 
                               FROM   dba_free_space 
                               GROUP BY tablespace_name) f, 
                              (SELECT SUM(bytes) AS total_bytes, 
                                      tablespace_name 
                               FROM   dba_data_files 
                               GROUP BY tablespace_name) d
                      WHERE    f.tablespace_name = d.tablespace_name
                      GROUP BY f.tablespace_name
                      UNION ALL
                      SELECT   tablespace_name,
                               SUM(bytes_used)
                      FROM     v$temp_space_header
                      GROUP BY tablespace_name) u
                      WHERE    u.tablespace_name(+) = t.tablespace_name))
ORDER BY tablespace_name
/
TTITLE off
PROMPT
CLEAR COLUMNS
CLEAR COMPUTE
SET FEEDBACK on

