--
-- Modified from the true_space.sql script by Tony 27th August 2014
-- 
-- Limit is currently hard-coded at 80%. if you need to change it here you'll
-- need to also change the 'grep -v' in amchecks.ksh.
--
WHENEVER OSERROR  EXIT 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET PAGES 1000
SET HEADING off
SET FEEDBACK off
SET LINES 200
SET SERVEROUTPUT on
SET TAB off

DECLARE
    TYPE t_tablespace IS TABLE OF VARCHAR2(200) INDEX BY PLS_INTEGER;
    v_database       v$database.name%TYPE:=SYS_CONTEXT('USERENV','DB_NAME');
    v_output         VARCHAR2(2000):=NULL;
    v_tablespace     t_tablespace;
BEGIN

    SELECT tablespace_name || ': ' ||  TO_CHAR(DECODE(tablespace_max_size,NULL,0,NVL(ROUND((tablespace_max_size - (tablespace_max_size - used_bytes))/(tablespace_max_size)*100,2),100))) || '% Full'
    BULK COLLECT INTO v_tablespace
      FROM   (SELECT t.tablespace_name,
                     t.tablespace_size,
                     t.tablespace_max_size,
                     nvl(u.used_bytes,0) AS used_bytes
              FROM   (SELECT tablespace_name,
                             SUM(totalb) AS tablespace_size,
                             SUM(maxb)   AS tablespace_max_size
                      FROM   (SELECT f.tablespace_name AS tablespace_name,
                                     SUM(LEAST(DECODE(NVL(f.maxbytes,0),0,bytes,f.maxbytes), (d.free_space))) AS maxb,
                                     SUM(f.bytes) AS totalb
                              FROM   dba_data_files f,
                                     amo.dfspace d
                              WHERE f.autoextensible = 'YES'
                              and  d.full_file_name = f.file_name
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT f.tablespace_name,
                                     SUM(LEAST(DECODE(NVL(f.maxbytes,0),0,bytes,f.maxbytes), (d.free_space))),
                                     SUM(f.bytes) AS totalb
                              FROM   dba_temp_files f,
                                     amo.dfspace d
                              WHERE f.autoextensible = 'YES'
                              and   d.full_file_name = f.file_name
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_data_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_temp_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name
                              UNION ALL
                              SELECT tablespace_name,
                                     SUM(bytes),
                                     SUM(bytes)
                              FROM  dba_temp_files
                              WHERE autoextensible = 'NO'
                              GROUP BY tablespace_name)
                     GROUP BY tablespace_name) t,
                     (SELECT  f.tablespace_name, 
                              SUM(d.total_bytes - f.free_bytes) AS used_bytes
                      FROM    (SELECT SUM(bytes) AS free_bytes,  
                                      tablespace_name 
                               FROM   dba_free_space 
                               GROUP BY tablespace_name) f, 
                              (SELECT SUM(bytes) AS total_bytes, 
                                      tablespace_name 
                               FROM   dba_data_files 
                               GROUP BY tablespace_name) d
                      WHERE    f.tablespace_name = d.tablespace_name
                      GROUP BY f.tablespace_name
                      UNION ALL
                      SELECT   tablespace_name,
                               SUM(bytes_used)
                      FROM     v$temp_space_header
                      GROUP BY tablespace_name) u
                      WHERE    u.tablespace_name(+) = t.tablespace_name)
    WHERE DECODE(tablespace_max_size,NULL,0,NVL(ROUND((tablespace_max_size - (tablespace_max_size - used_bytes))/(tablespace_max_size)*100,2),100)) > 80;

    FOR i IN 1 .. v_tablespace.COUNT
    LOOP
       IF (i > 1)
       THEN
           v_output:=v_output || '; ';
       END IF;
           v_output:=v_output || v_tablespace(i);
    END LOOP;

    IF (v_output IS NULL)
    THEN
        DBMS_OUTPUT.PUT_LINE('** No tablespace TRUE SPACE alerts for ' || v_database || ' **');
    ELSE
        DBMS_OUTPUT.PUT_LINE('** ERROR (tablespace TRUE SPACE alerts) on ' || v_database || ':- ' || v_output || ' **');
    END IF;

END;
/

