set lines 120
set pages 1000

prompt Script To Recreate the controlfile
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SELECT 'CREATE CONTROLFILE REUSE DATABASE "' || name || '" NORESETLOGS ' || log_mode AS x
FROM v$database 
UNION ALL
SELECT ' MAXLOGFILES ' || t.records_total
FROM v$controlfile_record_section t
WHERE t.type = 'REDO LOG'
UNION ALL
SELECT ' MAXLOGMEMBERS ' || dimlm
FROM sys.v_$kccdi
UNION ALL
SELECT ' MAXDATAFILES ' || t.records_total
FROM v$controlfile_record_section t
WHERE t.type = 'DATAFILE'
UNION ALL
SELECT ' MAXINSTANCES ' || t.records_total
FROM v$controlfile_record_section t
WHERE t.type = 'REDO THREAD'
UNION ALL
SELECT ' MAXLOGHISTORY ' || t.records_total
FROM v$controlfile_record_section t
WHERE T.TYPE = 'LOG HISTORY'
UNION ALL
SELECT 'LOGFILE'
FROM dual
UNION ALL
SELECT a.wibble || ' SIZE ' || z.bytes/1024/1024 || 'M BLOCKSIZE ' || z.blocksize || ','
FROM (SELECT group#, '  GROUP ' || group# || ' (' || LISTAGG('''' || member || '''', ', ') WITHIN GROUP (ORDER BY member) || ')' AS wibble FROM v$logfile
WHERE group# <> (SELECT MAX(group#) FROM v$log) GROUP BY group#) a, v$log z
WHERE a.group# = z.group#
UNION ALL
SELECT a.wibble || ' SIZE ' || z.bytes/1024/1024 || 'M BLOCKSIZE ' || z.blocksize
FROM (SELECT group#, '  GROUP ' || group# || ' (' || LISTAGG('''' || member || '''', ', ') WITHIN GROUP (ORDER BY member) || ')' AS wibble FROM v$logfile
WHERE group# = (SELECT MAX(group#) FROM v$log) GROUP BY group#) a, v$log z
WHERE a.group# = z.group#
UNION ALl
SELECT 'DATAFILE'
FROM dual
UNION ALL
SELECT * FROM (SELECT ' ''' || t.file_name || ''','
FROM dba_data_files t
WHERE t.file_id < (SELECT MAX(tt.file_id) FROM dba_data_files tt)
ORDER BY t.file_id ASC)
UNION ALL
SELECT ' ''' || t.file_name || ''''
FROM dba_data_files t
WHERE t.file_id = (SELECT MAX(tt.file_id) FROM dba_data_files tt)
UNION ALL
SELECT 'CHARACTER SET ' || value || ';' FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'
/

prompt



