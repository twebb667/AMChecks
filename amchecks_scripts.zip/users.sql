
CREATE PROFILE am_profile LIMIT
     PASSWORD_LIFE_TIME  UNLIMITED
     PASSWORD_GRACE_TIME DEFAULT
     PASSWORD_REUSE_MAX  UNLIMITED
     PASSWORD_REUSE_TIME UNLIMITED
     PASSWORD_LOCK_TIME  DEFAULT
     FAILED_LOGIN_ATTEMPTS 10;

CREATE USER amu PROFILE am_profile IDENTIFIED BY change_this;
GRANT CONNECT, SELECT_CATALOG_ROLE, CREATE TABLE TO amu;
--
-- Create table should not be with any quotas - this is just for external table creation (os space reporting)
-- GRANT SELECT ANY DICTIONARY TO amu;
-- You probably don't need 'SELECT ANY DICTIONARY' and it's not recommended. It's needed for password_expiry_check11.sql
-- and you can probably get by without that. SELECT_CATALOG_ROLE is probably a better option for granting access to the catalog
-- (or at least part of it).
--

CREATE USER amo PROFILE am_profile IDENTIFIED BY change_this;
GRANT CONNECT, RESOURCE, SELECT ANY DICTIONARY, CREATE ANY DIRECTORY, CREATE VIEW TO amo;
GRANT CREATE ANY SYNONYM TO amo;
GRANT CREATE TABLE TO amo;
ALTER USER amo QUOTA UNLIMITED ON users;

